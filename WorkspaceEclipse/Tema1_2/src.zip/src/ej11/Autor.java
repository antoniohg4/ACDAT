package ej11;

public class Autor {

	String nombre;
	String apellido;
}
