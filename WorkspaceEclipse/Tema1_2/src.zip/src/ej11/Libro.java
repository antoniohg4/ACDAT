package ej11;

public class Libro {
	
	long isbn;
	String titulo;
	Autor autor;
	int numEjemplares;
	
	public Libro() {
		
	}
}
