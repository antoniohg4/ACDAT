package ej11;

public class Libro {
	
	String isbn, titulo, autor;
	int numEjemplares;

	public Libro(String isbn, String titulo, String autor, int numEjemplares) {
		this.isbn = isbn;
		this.titulo = titulo;
		this.autor = autor;
		this.numEjemplares = numEjemplares;
	}
	
	public Libro(String[] arr) {
		this.isbn = arr[0];
		this.titulo = arr[1];
		this.autor = arr[2];
		this.numEjemplares = Integer.parseInt(arr[3]);
	}

	@Override
	public String toString() {
		return "Libro [isbn=" + isbn + ", titulo=" + titulo + ", autor=" + autor + ", numEjemplares=" + numEjemplares
				+ "]";
	}
		
}
