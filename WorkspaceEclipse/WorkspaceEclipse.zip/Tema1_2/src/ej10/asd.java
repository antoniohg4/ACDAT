public class asd {
   public static void main(String[] args) {
//Connect to MongoDB in java?
   } 

}
